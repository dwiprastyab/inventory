<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
*	Site Settings
*	
*	@author 	Noerman Agustiyan (@anoerman)
*	@version 	0.1.1
*	
*	Descriptions : 	You can add, edit or delete this site setting based on your 
*					preferences. Make sure the config name is unique.
*	
*/

$config['site_name']    = "Invenitri";
$config['site_slogan']  = "Integrated Inventory System V3";
$config['site_author']  = "Noerman Agustiyan";
$config['site_company'] = "Noerman Agustiyan";

