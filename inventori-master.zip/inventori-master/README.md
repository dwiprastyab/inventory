# Invenitri
Aplikasi inventory untuk melakukan pendataan barang. 
Invenitri adalah aplikasi berbasis web yang menggunakan bahasa pemrograman PHP dengan framework Codeigniter 3.1.6 
dan merupakan versi penyempurnaan dari aplikasi sebelumnya yaitu invenity. 
Menggunakan template AdminLTE 2.3.11 untuk tampilan yang lebih rapi.


## Cara penggunaan aplikasi 
- Download aplikasi
- Letakkan pada folder web server anda
- Buat database dan import file invenitri_database.sql
- Sesuaikan data koneksi database pada file config/database.php
- Sesuaikan pengaturan dasar aplikasi pada file config/site.php
- Akses aplikasi via browser

## Akses admin
- Username : administrator
- Password : password

## Catatan tambahan
Aplikasi ini masih dalam proses pengembangan, 
fitur saat ini hanya mencakup inventorisasi data sederhana dengan berbagai data master terkait. 
Pembuatan laporan masih dalam pengembangan.
